This is a Ransomware made for Linux. If the python file attached with this zip gets executed on victim's PC then all his/her files will b locked and Pop Up for Ransom will appear where Victim has to insert Decryption Key. if he/she types incorrect key in 1st attempt the ransomware will automatically delete all his/her files. To know about Decryption key you have to read the Python code... it generates random 16 digit Base64 hash key in a hidden file which u can see in the main directory...... also u have to modify the codes that where it will affect (directory). For any questions/queries ping me on Telegram.

Happy Ransom...

Join https://t.me/XploitWizer for more Hacking stuffs.


By @SHADOW2639 :)