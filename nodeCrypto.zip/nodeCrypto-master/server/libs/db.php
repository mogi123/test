<?php
$dbhost = "localhost";
$dbuser = "****";
$dbpass = "****";
$dbname = "****";
